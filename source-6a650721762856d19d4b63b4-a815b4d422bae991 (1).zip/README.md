# Aero Strange Grammar

Aero Strange Grammar is a premium offline-first writing assistant delivered as an installable Android-friendly Progressive Web App. Core grammar, spelling, punctuation, capitalization, article, agreement, tense, and readability checks run entirely on the device. The network is optional: authenticated users can synchronize history to Netlify Database and request advanced tone rewrites through Netlify AI Gateway.

## Key technologies

- TanStack Start, React 19, TypeScript, and Material-inspired responsive UI
- Deterministic local grammar engine with plain-English explanations
- Service worker and web app manifest for offline installation
- Local browser storage for guest history, favorites, and preferences
- Netlify Database with Drizzle ORM and deploy-time migrations
- Secure JWT sessions, scrypt password hashing, validation, and user-scoped queries
- Netlify AI Gateway with OpenAI `gpt-5.4-mini` for optional online rewriting

## Local development

1. Install Node.js 22 and run `npm install`.
2. Copy `.env.example` to `.env` and set a strong `JWT_SECRET`.
3. Start the full Netlify environment with `netlify dev --port 8889`.
4. Open the local URL shown by Netlify.

Focused grammar-engine tests are available through `npm test`.

The editor, grammar engine, history, search, favorites, settings, sharing, copy, print-to-PDF, and supported device voice recognition work without an account. After the application has loaded once, the service worker caches the app shell for offline use.

## Environment configuration

- `JWT_SECRET`: required for registration, login, profile, and cloud history endpoints; use at least 32 random characters.
- AI provider variables are supplied automatically by Netlify AI Gateway in deployment. For local gateway development, use the provider variables documented by Netlify.
- Netlify Database provisions its managed Postgres connection automatically. No connection string belongs in the repository.

Never commit `.env` files or credentials.

## API

- `POST /api/grammar/check` — deterministic grammar check for a text payload
- `POST /api/rewrite` — optional online tone rewrite through AI Gateway
- `POST /api/auth/register` — create an email account
- `POST /api/auth/login` — exchange credentials for a seven-day JWT
- `GET /api/profile` — fetch the authenticated profile
- `GET /api/history/` — fetch authenticated cloud history
- `POST /api/history/` — save a cloud history entry
- `DELETE /api/history/:id` — delete an owned cloud history entry

Authenticated endpoints expect `Authorization: Bearer <token>`. Request bodies are size-limited and validated. Database access uses parameterized Drizzle queries.

## Database and migrations

The canonical schema is `db/schema.ts`. It includes users, grammar history, saved documents, subscriptions, feedback, and user settings. Generated migrations live in `netlify/database/migrations/` and are applied automatically by Netlify.

For a schema change, edit `db/schema.ts`, then generate a descriptive migration:

```bash
npx drizzle-kit generate --name add_feature_name
```

## Offline architecture

`src/lib/grammar-engine.ts` is deliberately isolated behind a small result contract. A future WASM, ONNX Runtime Mobile, TensorFlow Lite, or LanguageTool adapter can replace it without changing the UI or persistence layers. The current engine prioritizes predictable, sub-second checks for common English errors and never requires a cloud request.

The PWA is installable from Chrome on Android 10 and newer. Native-only capabilities such as an embedded TFLite binary, Android secure keystore, Play Billing, and guaranteed offline speech packs require a dedicated Flutter/Android distribution layer; the current Netlify deployment provides the full web-installable product and keeps those engine boundaries replaceable.

## Deployment

Connect the repository to Netlify and deploy. Netlify uses `netlify.toml`, builds the TanStack Start application, provisions the database on first connection, applies the checked-in migration, and exposes server routes. Configure `JWT_SECRET` in the Netlify environment before enabling accounts. AI rewriting becomes available on Netlify plans that include AI Gateway.

## Privacy and security

Core checks are local by default. Cloud rewriting is explicit and optional. Passwords use salted scrypt hashes, JWTs expire after seven days, errors avoid leaking account details, and every history query is scoped to the authenticated user. Production traffic is served over Netlify HTTPS.
