# Aero Strange Grammar Agent Guide

## Architecture

This repository is a TanStack Start application deployed on Netlify. It is an offline-first PWA rather than a traditional server-dependent editor. Keep the local grammar path operational without network access.

- `src/routes/index.tsx`: main responsive application and view orchestration
- `src/lib/grammar-engine.ts`: deterministic on-device grammar engine and scoring contract
- `src/lib/storage.ts`: local history and preference persistence
- `src/routes/api/`: REST endpoints for accounts, history sync, grammar checks, and online rewrites
- `db/schema.ts`: canonical managed Postgres schema
- `db/index.ts`: Netlify Database Drizzle client
- `netlify/database/migrations/`: generated migrations applied during deployment
- `public/sw.js`: app-shell and runtime caching service worker
- `public/manifest.webmanifest`: Android-installable PWA metadata

## Conventions

Use strict TypeScript, descriptive names, functional React components, and accessible native controls. Keep UI state local unless it must survive reloads. Persistent structured server data must use Netlify Database; guest data remains in browser storage because offline operation is a product requirement.

Never place grammar checking behind a network request. Optional cloud features must fail gracefully and leave local functionality intact. Avoid sending writing to a server unless the user explicitly chooses an online enhancement.

## Database changes

Use `drizzle-orm@beta` and `drizzle-kit@beta` with the Netlify adapter. Every schema change requires a generated migration in `netlify/database/migrations/` using a descriptive snake_case name.

## Visual system

The design uses navy `#0B1F3A`, mint `#00D084`, a restrained editorial layout, Manrope headings, DM Sans body copy, rounded cards, and low-contrast shadows. Preserve the premium, professional tone and test layouts conceptually at phone, tablet, and desktop widths.

## Non-obvious decisions

The local engine is rule-based and modular so a future WASM/ONNX/TFLite adapter can implement the same `GrammarResult` interface. PDF export uses the browser print pipeline to remain offline and dependency-light. Device speech recognition is used only when the browser exposes it and degrades to a clear message otherwise.
