import { createFileRoute } from '@tanstack/react-router'
import { desc, eq } from 'drizzle-orm'
import { db } from '../../../../db/index'
import { grammarHistory } from '../../../../db/schema'
import { jsonError, readJson } from '../../../lib/api'
import { requireUser } from '../../../lib/server-auth'

export const Route = createFileRoute('/api/history/')({ server: { handlers: {
  GET: async ({ request }) => {
    try { const userId = await requireUser(request); return Response.json(await db.select().from(grammarHistory).where(eq(grammarHistory.userId, userId)).orderBy(desc(grammarHistory.createdAt)).limit(250)) }
    catch (error) { return error instanceof Response ? error : jsonError('Unable to load history', 500) }
  },
  POST: async ({ request }) => {
    try {
      const userId = await requireUser(request)
      const body = await readJson<{ original?: unknown; corrected?: unknown; issues?: unknown[]; score?: unknown; readability?: unknown; mode?: unknown }>(request)
      if (typeof body.original !== 'string' || typeof body.corrected !== 'string' || body.original.length > 100_000 || body.corrected.length > 100_000) return jsonError('Invalid document')
      const [entry] = await db.insert(grammarHistory).values({ userId, originalText: body.original, correctedText: body.corrected, issues: Array.isArray(body.issues) ? body.issues : [], score: Number(body.score) || 0, readability: Number(body.readability) || 0, mode: body.mode === 'online' ? 'online' : 'offline' }).returning()
      return Response.json(entry, { status: 201 })
    } catch (error) { return error instanceof Response ? error : jsonError('Unable to save history', 500) }
  },
} } })
