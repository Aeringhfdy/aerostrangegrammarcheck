import { createFileRoute } from '@tanstack/react-router'
import { and, eq } from 'drizzle-orm'
import { db } from '../../../../db/index'
import { grammarHistory } from '../../../../db/schema'
import { jsonError } from '../../../lib/api'
import { requireUser } from '../../../lib/server-auth'

export const Route = createFileRoute('/api/history/$id')({ server: { handlers: { DELETE: async ({ request, params }) => {
  try {
    const userId = await requireUser(request)
    const deleted = await db.delete(grammarHistory).where(and(eq(grammarHistory.id, params.id), eq(grammarHistory.userId, userId))).returning({ id: grammarHistory.id })
    return deleted.length ? new Response(null, { status: 204 }) : jsonError('History item not found', 404)
  } catch (error) { return error instanceof Response ? error : jsonError('Unable to delete history', 500) }
} } } })
