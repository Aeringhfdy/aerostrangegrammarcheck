import { createFileRoute } from '@tanstack/react-router'
import OpenAI from 'openai'
import { jsonError, readJson } from '../../lib/api'

const allowedTones = new Set(['professional', 'academic', 'business', 'formal', 'casual', 'concise'])

export const Route = createFileRoute('/api/rewrite')({ server: { handlers: { POST: async ({ request }) => {
  try {
    const body = await readJson<{ text?: unknown; tone?: unknown }>(request)
    if (typeof body.text !== 'string' || !body.text.trim() || body.text.length > 30_000) return jsonError('Valid text is required')
    const tone = typeof body.tone === 'string' && allowedTones.has(body.tone.toLowerCase()) ? body.tone.toLowerCase() : 'professional'
    const openai = new OpenAI()
    const response = await openai.responses.create({ model: 'gpt-5.4-mini', input: `Rewrite the text in a ${tone} tone. Preserve meaning and facts. Return only the rewritten text.\n\n${body.text}` })
    return Response.json({ corrected: response.output_text, mode: 'online', tone })
  } catch (error) {
    console.error('rewrite_failed', error instanceof Error ? error.message : 'unknown')
    return jsonError('Online rewriting is temporarily unavailable', 503)
  }
} } } })
