import { createFileRoute } from '@tanstack/react-router'
import { eq } from 'drizzle-orm'
import { db } from '../../../db/index'
import { users, userSettings } from '../../../db/schema'
import { jsonError } from '../../lib/api'
import { requireUser } from '../../lib/server-auth'

export const Route = createFileRoute('/api/profile')({ server: { handlers: { GET: async ({ request }) => {
  try {
    const userId = await requireUser(request)
    const [profile] = await db.select({ id: users.id, email: users.email, displayName: users.displayName, createdAt: users.createdAt, theme: userSettings.theme, language: userSettings.language, cloudEnhancements: userSettings.cloudEnhancements }).from(users).leftJoin(userSettings, eq(users.id, userSettings.userId)).where(eq(users.id, userId)).limit(1)
    return profile ? Response.json(profile) : jsonError('Profile not found', 404)
  } catch (error) { return error instanceof Response ? error : jsonError('Unable to load profile', 500) }
} } } })
