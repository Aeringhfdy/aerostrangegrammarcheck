import { createFileRoute } from '@tanstack/react-router'
import { jsonError, readJson } from '../../../lib/api'
import { checkGrammar } from '../../../lib/grammar-engine'

export const Route = createFileRoute('/api/grammar/check')({ server: { handlers: { POST: async ({ request }) => {
  try {
    const body = await readJson<{ text?: unknown }>(request)
    if (typeof body.text !== 'string' || !body.text.trim()) return jsonError('Text is required')
    if (body.text.length > 100_000) return jsonError('Text is too long', 413)
    return Response.json(checkGrammar(body.text))
  } catch (error) { return error instanceof Response ? error : jsonError('Unable to check writing', 500) }
} } } })
