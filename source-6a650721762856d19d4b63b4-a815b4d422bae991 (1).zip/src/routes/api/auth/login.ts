import { createFileRoute } from '@tanstack/react-router'
import { eq } from 'drizzle-orm'
import { db } from '../../../../db/index'
import { users } from '../../../../db/schema'
import { jsonError, readJson } from '../../../lib/api'
import { issueToken, validateEmail, verifyPassword } from '../../../lib/server-auth'

export const Route = createFileRoute('/api/auth/login')({ server: { handlers: { POST: async ({ request }) => {
  try {
    const body = await readJson<{ email?: unknown; password?: unknown }>(request, 10_000)
    if (!validateEmail(body.email) || typeof body.password !== 'string') return jsonError('Invalid credentials', 401)
    const [user] = await db.select().from(users).where(eq(users.email, body.email.toLowerCase())).limit(1)
    if (!user?.passwordHash || !verifyPassword(body.password, user.passwordHash)) return jsonError('Invalid credentials', 401)
    return Response.json({ user: { id: user.id, email: user.email, displayName: user.displayName }, token: await issueToken(user.id, user.email) })
  } catch (error) {
    if (error instanceof Response) return error
    console.error('login_failed', error instanceof Error ? error.message : 'unknown')
    return jsonError('Unable to sign in', 500)
  }
} } } })
