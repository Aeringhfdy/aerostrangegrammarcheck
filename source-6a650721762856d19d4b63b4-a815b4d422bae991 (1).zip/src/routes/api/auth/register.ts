import { createFileRoute } from '@tanstack/react-router'
import { eq } from 'drizzle-orm'
import { db } from '../../../../db/index'
import { users, userSettings } from '../../../../db/schema'
import { jsonError, readJson } from '../../../lib/api'
import { hashPassword, issueToken, validateEmail, validatePassword } from '../../../lib/server-auth'

export const Route = createFileRoute('/api/auth/register')({ server: { handlers: { POST: async ({ request }) => {
  try {
    const body = await readJson<{ email?: unknown; password?: unknown; displayName?: unknown }>(request, 10_000)
    if (!validateEmail(body.email)) return jsonError('Enter a valid email address')
    if (!validatePassword(body.password)) return jsonError('Password must be 10–128 characters')
    const displayName = typeof body.displayName === 'string' ? body.displayName.trim().slice(0, 120) : ''
    if (displayName.length < 2) return jsonError('Display name is required')
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, body.email.toLowerCase())).limit(1)
    if (existing.length) return jsonError('An account already exists for this email', 409)
    const [user] = await db.insert(users).values({ email: body.email.toLowerCase(), displayName, passwordHash: hashPassword(body.password) }).returning({ id: users.id, email: users.email, displayName: users.displayName })
    await db.insert(userSettings).values({ userId: user.id })
    return Response.json({ user, token: await issueToken(user.id, user.email) }, { status: 201 })
  } catch (error) {
    if (error instanceof Response) return error
    console.error('register_failed', error instanceof Error ? error.message : 'unknown')
    return jsonError('Unable to create account', 500)
  }
} } } })
