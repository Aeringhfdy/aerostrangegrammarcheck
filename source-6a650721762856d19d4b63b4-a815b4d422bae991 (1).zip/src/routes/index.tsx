import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useMemo, useRef, useState } from 'react'
import {
  ArrowRight, BookOpen, Check, ChevronRight, Clipboard, Clock3, Cloud,
  Copy, Download, FileText, Heart, History, Languages, Menu, Mic, Moon,
  MoreHorizontal, PenLine, Redo2, Search, Settings, Share2, ShieldCheck,
  Sparkles, Sun, Trash2, Undo2, UserRound, WifiOff, X, Zap,
} from 'lucide-react'
import { checkGrammar, type GrammarResult, type IssueCategory } from '../lib/grammar-engine'
import { defaultSettings, getHistory, getSettings, replaceHistory, saveHistory, saveSettings, type AppSettings, type HistoryEntry } from '../lib/storage'

export const Route = createFileRoute('/')({ component: AeroGrammar })

type View = 'write' | 'history' | 'settings'
type Tone = 'Standard' | 'Professional' | 'Academic' | 'Business' | 'Casual'

const sample = 'i likes apple yesterday  it was definately a very unique experience'
const categoryLabels: Record<IssueCategory, string> = {
  grammar: 'Grammar', spelling: 'Spelling', punctuation: 'Punctuation', capitalization: 'Capitalization', style: 'Readability',
}

function AeroGrammar() {
  const [view, setView] = useState<View>('write')
  const [text, setText] = useState('')
  const [result, setResult] = useState<GrammarResult | null>(null)
  const [history, setHistory] = useState<HistoryEntry[]>([])
  const [settings, setSettingsState] = useState<AppSettings>(defaultSettings)
  const [tone, setTone] = useState<Tone>('Standard')
  const [online, setOnline] = useState(true)
  const [checking, setChecking] = useState(false)
  const [toast, setToast] = useState('')
  const [search, setSearch] = useState('')
  const [mobileNav, setMobileNav] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const [undoStack, setUndoStack] = useState<string[]>([])
  const [redoStack, setRedoStack] = useState<string[]>([])
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    setHistory(getHistory())
    setSettingsState(getSettings())
    const updateOnline = () => setOnline(navigator.onLine)
    updateOnline()
    window.addEventListener('online', updateOnline)
    window.addEventListener('offline', updateOnline)
    navigator.serviceWorker?.register('/sw.js').catch(() => undefined)
    return () => { window.removeEventListener('online', updateOnline); window.removeEventListener('offline', updateOnline) }
  }, [])

  useEffect(() => {
    const dark = settings.theme === 'dark' || (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)
    document.documentElement.dataset.theme = dark ? 'dark' : 'light'
    document.documentElement.style.setProperty('--font-scale', String(settings.fontScale))
    saveSettings(settings)
  }, [settings])

  const words = text.trim() ? text.trim().split(/\s+/).length : 0
  const filteredHistory = useMemo(() => history.filter(item => `${item.original} ${item.corrected}`.toLowerCase().includes(search.toLowerCase())), [history, search])

  function notify(message: string) {
    setToast(message)
    window.setTimeout(() => setToast(''), 2200)
  }

  function updateText(next: string) {
    if (next !== text) setUndoStack(stack => [...stack.slice(-30), text])
    setText(next)
    setRedoStack([])
    if (result) setResult(null)
  }

  function runCheck() {
    if (!text.trim()) { notify('Add some writing first'); textareaRef.current?.focus(); return }
    setChecking(true)
    window.setTimeout(() => {
      const checked = checkGrammar(text)
      setResult(checked)
      const entry = saveHistory(checked)
      setHistory(items => [entry, ...items].slice(0, 250))
      setChecking(false)
    }, 420)
  }

  async function copy(value: string) {
    await navigator.clipboard.writeText(value)
    notify('Copied to clipboard')
  }

  async function paste() {
    try { updateText(await navigator.clipboard.readText()) } catch { notify('Clipboard permission is unavailable') }
  }

  function undo() {
    const previous = undoStack.at(-1)
    if (previous === undefined) return
    setRedoStack(stack => [...stack, text]); setText(previous); setUndoStack(stack => stack.slice(0, -1)); setResult(null)
  }

  function redo() {
    const next = redoStack.at(-1)
    if (next === undefined) return
    setUndoStack(stack => [...stack, text]); setText(next); setRedoStack(stack => stack.slice(0, -1)); setResult(null)
  }

  function startVoice() {
    const SpeechRecognition = (window as typeof window & { webkitSpeechRecognition?: new () => SpeechRecognitionLike }).webkitSpeechRecognition
    if (!SpeechRecognition) { notify('Offline voice typing depends on your device'); return }
    const recognition = new SpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = false
    recognition.onresult = event => updateText(`${text}${text ? ' ' : ''}${event.results[0][0].transcript}`)
    recognition.onerror = () => notify('Voice typing could not start')
    recognition.start()
    notify('Listening…')
  }

  function updateSettings(patch: Partial<AppSettings>) { setSettingsState(current => ({ ...current, ...patch })) }

  function toggleFavorite(id: string) {
    const next = history.map(item => item.id === id ? { ...item, favorite: !item.favorite } : item)
    setHistory(next); replaceHistory(next)
  }

  function removeHistory(id: string) {
    const next = history.filter(item => item.id !== id)
    setHistory(next); replaceHistory(next); notify('History item deleted')
  }

  function openHistory(item: HistoryEntry) { setText(item.original); setResult(item); setView('write') }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
        <button className="mobile-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><X /></button>
        <Logo />
        <nav className="nav-list" aria-label="Main navigation">
          <NavButton active={view === 'write'} icon={<PenLine />} label="Write" onClick={() => { setView('write'); setMobileNav(false) }} />
          <NavButton active={view === 'history'} icon={<History />} label="History" badge={history.length || undefined} onClick={() => { setView('history'); setMobileNav(false) }} />
          <NavButton active={view === 'settings'} icon={<Settings />} label="Settings" onClick={() => { setView('settings'); setMobileNav(false) }} />
        </nav>
        <div className="sidebar-card">
          <div className="mini-orbit"><Sparkles size={18} /></div>
          <strong>Write with confidence.</strong>
          <p>Your essential grammar tools run privately on this device.</p>
          <span><ShieldCheck size={14} /> Offline by design</span>
        </div>
        <button className="profile-button" onClick={() => setShowProfile(true)}>
          <span className="avatar">AS</span><span><strong>Guest writer</strong><small>Local workspace</small></span><MoreHorizontal size={18} />
        </button>
      </aside>

      {mobileNav && <button className="scrim" aria-label="Close navigation" onClick={() => setMobileNav(false)} />}

      <main className="main">
        <header className="topbar">
          <button className="icon-button mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu /></button>
          <div className={`mode-pill ${online ? '' : 'offline'}`}>{online ? <Cloud size={15} /> : <WifiOff size={15} />} {online ? 'Online enhancements ready' : 'Offline engine active'}</div>
          <div className="top-actions">
            <button className="icon-button" onClick={() => updateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' })} aria-label="Toggle theme">{settings.theme === 'dark' ? <Sun /> : <Moon />}</button>
            <button className="avatar compact" onClick={() => setShowProfile(true)}>AS</button>
          </div>
        </header>

        {view === 'write' && (
          <section className="content write-view">
            <div className="hero-copy">
              <span className="eyebrow"><span /> PRIVATE WRITING INTELLIGENCE</span>
              <h1>Make every sentence<br /><em>land beautifully.</em></h1>
              <p>Polish grammar, punctuation, spelling, and clarity in seconds—even when the internet disappears.</p>
            </div>

            <div className="workspace">
              <div className="editor-card">
                <div className="editor-header">
                  <div><span className="status-dot" /> New document</div>
                  <div className="editor-tools">
                    <button onClick={undo} disabled={!undoStack.length} aria-label="Undo"><Undo2 /></button>
                    <button onClick={redo} disabled={!redoStack.length} aria-label="Redo"><Redo2 /></button>
                    <span />
                    <button onClick={paste}><Clipboard /> Paste</button>
                    <button onClick={() => { updateText(''); setResult(null) }}><Trash2 /> Clear</button>
                  </div>
                </div>
                <textarea ref={textareaRef} value={text} onChange={event => updateText(event.target.value)} placeholder="Start writing something remarkable…" spellCheck={false} />
                {!text && <button className="sample-link" onClick={() => updateText(sample)}>Try an example <ArrowRight size={14} /></button>}
                <div className="editor-footer">
                  <div className="counts"><span>{words} words</span><span>{text.length} characters</span></div>
                  <div className="editor-actions">
                    <button className="voice-button" onClick={startVoice}><Mic /> <span>Voice</span></button>
                    <select value={tone} onChange={event => setTone(event.target.value as Tone)} aria-label="Writing tone">
                      {(['Standard', 'Professional', 'Academic', 'Business', 'Casual'] as Tone[]).map(item => <option key={item}>{item}</option>)}
                    </select>
                    <button className="check-button" onClick={runCheck} disabled={checking}>{checking ? <span className="spinner" /> : <Sparkles />} {checking ? 'Checking…' : 'Check writing'} <ChevronRight /></button>
                  </div>
                </div>
              </div>

              {result ? <Results result={result} onCopy={() => copy(result.corrected)} onUse={() => { updateText(result.corrected); setResult(null); notify('Correction applied') }} onShare={async () => { if (navigator.share) await navigator.share({ title: 'Aero Strange Grammar', text: result.corrected }); else copy(result.corrected) }} /> : <EmptyInsight />}
            </div>
            <div className="trust-row"><span><Zap /> Under 1 second</span><span><ShieldCheck /> Stays on device</span><span><BookOpen /> Plain-English guidance</span></div>
          </section>
        )}

        {view === 'history' && <HistoryView items={filteredHistory} search={search} setSearch={setSearch} onOpen={openHistory} onFavorite={toggleFavorite} onDelete={removeHistory} />}
        {view === 'settings' && <SettingsView settings={settings} update={updateSettings} historyCount={history.length} clearHistory={() => { setHistory([]); replaceHistory([]); notify('Local history cleared') }} />}
      </main>

      {showProfile && <ProfileModal onClose={() => setShowProfile(false)} />}
      {toast && <div className="toast"><Check size={17} /> {toast}</div>}
    </div>
  )
}

interface SpeechRecognitionLike {
  continuous: boolean
  interimResults: boolean
  onresult: (event: { results: { 0: { 0: { transcript: string } } } }) => void
  onerror: () => void
  start: () => void
}

function Logo() {
  return <div className="logo"><div className="logo-mark"><span /><span /><span /></div><div><strong>AERO</strong><small>STRANGE GRAMMAR</small></div></div>
}

function NavButton({ active, icon, label, badge, onClick }: { active: boolean; icon: React.ReactNode; label: string; badge?: number; onClick: () => void }) {
  return <button className={active ? 'active' : ''} onClick={onClick}>{icon}<span>{label}</span>{badge ? <b>{badge}</b> : null}</button>
}

function EmptyInsight() {
  return <aside className="insight-card empty-insight"><div className="insight-visual"><div className="score-ring"><span>—</span></div><Sparkles /></div><h2>Your writing report</h2><p>Corrections, clarity signals, and simple explanations appear here after a check.</p><div className="empty-lines"><span /><span /><span /></div></aside>
}

function Results({ result, onCopy, onUse, onShare }: { result: GrammarResult; onCopy: () => void; onUse: () => void; onShare: () => void }) {
  const counts = result.issues.reduce<Record<string, number>>((acc, issue) => ({ ...acc, [issue.category]: (acc[issue.category] ?? 0) + 1 }), {})
  return <aside className="insight-card result-card">
    <div className="result-title"><div><span className="eyebrow">WRITING REPORT</span><h2>{result.issues.length ? `${result.issues.length} improvements found` : 'Looking polished'}</h2></div><div className="score-ring"><span>{result.score}</span><small>SCORE</small></div></div>
    <div className="corrected-box"><div><strong>Polished version</strong><div className="inline-actions"><button onClick={onCopy} aria-label="Copy"><Copy /></button><button onClick={onShare} aria-label="Share"><Share2 /></button><button onClick={() => window.print()} aria-label="Export PDF"><Download /></button></div></div><p>{result.corrected}</p><button className="use-button" onClick={onUse}>Use this version <ArrowRight /></button></div>
    <div className="metrics"><div><strong>{result.readability}</strong><span>Readability</span></div><div><strong>{result.words}</strong><span>Words</span></div><div><strong>{result.sentences}</strong><span>Sentences</span></div></div>
    <div className="issue-summary">
      {(['grammar', 'spelling', 'punctuation', 'capitalization', 'style'] as IssueCategory[]).filter(category => counts[category]).map(category => <span key={category} className={`tag ${category}`}>{counts[category]} {categoryLabels[category]}</span>)}
    </div>
    <div className="explanations">
      {result.issues.length ? result.issues.map(issue => <article key={issue.id}><div className={`issue-icon ${issue.category}`}><PenLine /></div><div><strong><s>{issue.original}</s> <ArrowRight /> {issue.replacement}</strong><p>{issue.explanation}</p></div></article>) : <article><div className="issue-icon clean"><Check /></div><div><strong>No obvious errors found</strong><p>Your writing is clear and mechanically sound.</p></div></article>}
    </div>
    <div className="privacy-note"><ShieldCheck /> Checked locally. Your writing never left this device.</div>
  </aside>
}

function HistoryView({ items, search, setSearch, onOpen, onFavorite, onDelete }: { items: HistoryEntry[]; search: string; setSearch: (value: string) => void; onOpen: (item: HistoryEntry) => void; onFavorite: (id: string) => void; onDelete: (id: string) => void }) {
  return <section className="content page-view"><div className="page-heading"><div><span className="eyebrow"><Clock3 /> LOCAL ARCHIVE</span><h1>Your writing history.</h1><p>Every correction stays available offline on this device.</p></div><div className="search-box"><Search /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search corrections" /></div></div>
    {items.length ? <div className="history-grid">{items.map(item => <article className="history-card" key={item.id}><div className="history-meta"><span>{new Date(item.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span><span className="score-chip">{item.score} score</span></div><h3>{item.corrected.slice(0, 75)}{item.corrected.length > 75 ? '…' : ''}</h3><p>{item.original}</p><div className="history-footer"><span>{item.issues.length} improvements</span><div><button onClick={() => onFavorite(item.id)} aria-label="Favorite">{item.favorite ? <Heart fill="currentColor" /> : <Heart />}</button><button onClick={() => onDelete(item.id)} aria-label="Delete"><Trash2 /></button><button className="open-link" onClick={() => onOpen(item)}>Open <ArrowRight /></button></div></div></article>)}</div> : <div className="empty-page"><div><FileText /></div><h2>No corrections yet</h2><p>Your offline writing history appears here after your first check.</p></div>}
  </section>
}

function SettingsView({ settings, update, historyCount, clearHistory }: { settings: AppSettings; update: (patch: Partial<AppSettings>) => void; historyCount: number; clearHistory: () => void }) {
  return <section className="content page-view settings-view"><div className="page-heading"><div><span className="eyebrow"><Settings /> PERSONAL WORKSPACE</span><h1>Shape your experience.</h1><p>Preferences stay synchronized with your local workspace.</p></div></div>
    <div className="settings-grid">
      <SettingsSection title="Appearance" subtitle="Make Aero comfortable for every writing session" icon={<Sun />}>
        <SettingRow label="Color theme" description="Choose a light, dark, or device-matched appearance"><div className="segmented">{(['light', 'dark', 'system'] as const).map(theme => <button className={settings.theme === theme ? 'active' : ''} onClick={() => update({ theme })} key={theme}>{theme}</button>)}</div></SettingRow>
        <SettingRow label="Editor size" description="Scale writing and interface text"><input type="range" min="0.9" max="1.2" step="0.05" value={settings.fontScale} onChange={event => update({ fontScale: Number(event.target.value) })} /></SettingRow>
      </SettingsSection>
      <SettingsSection title="Language & intelligence" subtitle="Control how the writing engine behaves" icon={<Languages />}>
        <SettingRow label="Writing language" description="Offline rules are optimized for English"><select value={settings.language} onChange={event => update({ language: event.target.value })}><option>English (US)</option><option>English (UK)</option><option>English (Australia)</option></select></SettingRow>
        <SettingRow label="Online enhancements" description="Use advanced tone rewriting only when connected"><Toggle checked={settings.cloudEnhancements} onChange={value => update({ cloudEnhancements: value })} /></SettingRow>
        <SettingRow label="Writing reminders" description="Show occasional prompts to review saved drafts"><Toggle checked={settings.notifications} onChange={value => update({ notifications: value })} /></SettingRow>
      </SettingsSection>
      <SettingsSection title="Privacy & storage" subtitle="Your offline data remains under your control" icon={<ShieldCheck />}>
        <SettingRow label="Local history" description={`${historyCount} corrections stored on this device`}><button className="danger-button" onClick={clearHistory}>Clear history</button></SettingRow>
        <SettingRow label="Privacy standard" description="Core grammar checks never send writing to a server"><span className="secure-label"><ShieldCheck /> On-device</span></SettingRow>
      </SettingsSection>
    </div>
  </section>
}

function SettingsSection({ title, subtitle, icon, children }: { title: string; subtitle: string; icon: React.ReactNode; children: React.ReactNode }) {
  return <article className="settings-card"><header><div className="settings-icon">{icon}</div><div><h2>{title}</h2><p>{subtitle}</p></div></header><div>{children}</div></article>
}
function SettingRow({ label, description, children }: { label: string; description: string; children: React.ReactNode }) { return <div className="setting-row"><div><strong>{label}</strong><p>{description}</p></div>{children}</div> }
function Toggle({ checked, onChange }: { checked: boolean; onChange: (value: boolean) => void }) { return <button className={`toggle ${checked ? 'on' : ''}`} onClick={() => onChange(!checked)} aria-pressed={checked}><span /></button> }

function ProfileModal({ onClose }: { onClose: () => void }) {
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="profile-modal" onMouseDown={event => event.stopPropagation()}><button className="modal-close" onClick={onClose}><X /></button><div className="profile-hero"><div className="avatar large">AS</div><span className="eyebrow">OPTIONAL ACCOUNT</span><h2>Keep privacy at the center.</h2><p>Guest mode is fully functional. Create an account only when you want encrypted cloud backup across devices.</p></div><button className="auth-button primary"><UserRound /> Continue with email</button><button className="auth-button"><span className="google-g">G</span> Continue with Google</button><div className="guest-note"><ShieldCheck /> You are using private guest mode. No account is required.</div></div></div>
}
