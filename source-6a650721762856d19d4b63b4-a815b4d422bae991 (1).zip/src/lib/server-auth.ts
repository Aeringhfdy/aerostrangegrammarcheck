import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto'
import { SignJWT, jwtVerify } from 'jose'

const encoder = new TextEncoder()

function secret() {
  const value = process.env.JWT_SECRET
  if (!value || value.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters')
  return encoder.encode(value)
}

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string) {
  const [salt, expectedHex] = stored.split(':')
  if (!salt || !expectedHex) return false
  const actual = scryptSync(password, salt, 64)
  const expected = Buffer.from(expectedHex, 'hex')
  return actual.length === expected.length && timingSafeEqual(actual, expected)
}

export async function issueToken(userId: string, email: string) {
  return new SignJWT({ email }).setProtectedHeader({ alg: 'HS256' }).setSubject(userId).setIssuedAt().setExpirationTime('7d').sign(secret())
}

export async function requireUser(request: Request) {
  const authorization = request.headers.get('authorization')
  if (!authorization?.startsWith('Bearer ')) throw new Response('Unauthorized', { status: 401 })
  try {
    const { payload } = await jwtVerify(authorization.slice(7), secret())
    if (!payload.sub) throw new Error('Missing subject')
    return payload.sub
  } catch {
    throw new Response('Unauthorized', { status: 401 })
  }
}

export function validateEmail(email: unknown): email is string {
  return typeof email === 'string' && email.length <= 320 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function validatePassword(password: unknown): password is string {
  return typeof password === 'string' && password.length >= 10 && password.length <= 128
}
