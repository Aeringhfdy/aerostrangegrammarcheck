import type { GrammarResult } from './grammar-engine'

export interface HistoryEntry extends GrammarResult {
  id: string
  createdAt: string
  favorite: boolean
}

const HISTORY_KEY = 'aero-grammar-history-v1'
const SETTINGS_KEY = 'aero-grammar-settings-v1'

export type AppSettings = {
  theme: 'light' | 'dark' | 'system'
  fontScale: number
  language: string
  cloudEnhancements: boolean
  notifications: boolean
}

export const defaultSettings: AppSettings = {
  theme: 'light',
  fontScale: 1,
  language: 'English (US)',
  cloudEnhancements: true,
  notifications: false,
}

export function getHistory(): HistoryEntry[] {
  if (typeof window === 'undefined') return []
  try { return JSON.parse(localStorage.getItem(HISTORY_KEY) ?? '[]') } catch { return [] }
}

export function saveHistory(result: GrammarResult) {
  const entry: HistoryEntry = { ...result, id: crypto.randomUUID(), createdAt: new Date().toISOString(), favorite: false }
  localStorage.setItem(HISTORY_KEY, JSON.stringify([entry, ...getHistory()].slice(0, 250)))
  return entry
}

export function replaceHistory(entries: HistoryEntry[]) {
  localStorage.setItem(HISTORY_KEY, JSON.stringify(entries))
}

export function getSettings(): AppSettings {
  if (typeof window === 'undefined') return defaultSettings
  try { return { ...defaultSettings, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) ?? '{}') } } catch { return defaultSettings }
}

export function saveSettings(settings: AppSettings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
}
