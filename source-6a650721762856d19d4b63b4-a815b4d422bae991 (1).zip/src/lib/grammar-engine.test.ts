import { describe, expect, it } from 'vitest'
import { checkGrammar } from './grammar-engine'

describe('offline grammar engine', () => {
  it('corrects agreement, tense, articles, capitalization, spelling, and punctuation', () => {
    const result = checkGrammar('i likes apple yesterday it was definately good')

    expect(result.corrected).toBe('I liked an apple yesterday it was definitely good.')
    expect(result.mode).toBe('offline')
    expect(result.issues.length).toBeGreaterThanOrEqual(5)
  })

  it('adds apostrophes and question punctuation', () => {
    const result = checkGrammar('why dont you go')

    expect(result.corrected).toBe("Why don't you go?")
    expect(result.issues.some(issue => issue.explanation.includes('apostrophe'))).toBe(true)
  })

  it('returns a perfect score for clean short writing', () => {
    const result = checkGrammar('The document is ready.')

    expect(result.corrected).toBe('The document is ready.')
    expect(result.score).toBe(100)
    expect(result.issues).toHaveLength(0)
  })
})
