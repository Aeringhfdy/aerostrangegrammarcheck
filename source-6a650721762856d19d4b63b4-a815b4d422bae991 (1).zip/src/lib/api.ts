export function jsonError(message: string, status = 400) {
  return Response.json({ error: message }, { status })
}

export async function readJson<T>(request: Request, maxBytes = 100_000): Promise<T> {
  const length = Number(request.headers.get('content-length') ?? 0)
  if (length > maxBytes) throw new Response('Payload too large', { status: 413 })
  return request.json() as Promise<T>
}
