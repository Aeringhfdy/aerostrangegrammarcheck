export type IssueCategory = 'grammar' | 'spelling' | 'punctuation' | 'capitalization' | 'style'

export interface GrammarIssue {
  id: string
  category: IssueCategory
  original: string
  replacement: string
  explanation: string
}

export interface GrammarResult {
  original: string
  corrected: string
  issues: GrammarIssue[]
  score: number
  readability: number
  words: number
  sentences: number
  mode: 'offline' | 'online'
}

type Rule = {
  category: IssueCategory
  pattern: RegExp
  replacement: string | ((substring: string, ...args: string[]) => string)
  explanation: (match: string, replacement: string) => string
}

const rules: Rule[] = [
  {
    category: 'grammar',
    pattern: /\bi\b/g,
    replacement: 'I',
    explanation: () => 'The pronoun “I” is always capitalized.',
  },
  {
    category: 'grammar',
    pattern: /\b(I|you|we|they) (is|was)\b/gi,
    replacement: (_, subject: string, verb: string) => `${subject} ${verb.toLowerCase() === 'is' ? 'are' : 'were'}`,
    explanation: () => 'The verb now agrees with its plural or second-person subject.',
  },
  {
    category: 'grammar',
    pattern: /\b(he|she|it) (are|were)\b/gi,
    replacement: (_, subject: string, verb: string) => `${subject} ${verb.toLowerCase() === 'are' ? 'is' : 'was'}`,
    explanation: () => 'The singular subject needs a singular form of the verb.',
  },
  {
    category: 'grammar',
    pattern: /\b(I|you|we|they) (likes|goes|does|has)\b/gi,
    replacement: (_, subject: string, verb: string) => {
      const base: Record<string, string> = { likes: 'like', goes: 'go', does: 'do', has: 'have' }
      return `${subject} ${base[verb.toLowerCase()]}`
    },
    explanation: () => 'The base verb form agrees with this subject.',
  },
  {
    category: 'grammar',
    pattern: /\b(he|she|it) (like|go|do|have)\b/gi,
    replacement: (_, subject: string, verb: string) => {
      const singular: Record<string, string> = { like: 'likes', go: 'goes', do: 'does', have: 'has' }
      return `${subject} ${singular[verb.toLowerCase()]}`
    },
    explanation: () => 'The verb now agrees with the third-person singular subject.',
  },
  {
    category: 'grammar',
    pattern: /\b(like|likes|go|goes|eat|eats|see|sees)\b(?=[^.!?]*\b(yesterday|last (?:night|week|month|year))\b)/gi,
    replacement: (verb: string) => {
      const past: Record<string, string> = { like: 'liked', likes: 'liked', go: 'went', goes: 'went', eat: 'ate', eats: 'ate', see: 'saw', sees: 'saw' }
      return past[verb.toLowerCase()] ?? verb
    },
    explanation: () => 'The verb was changed to past tense because the sentence refers to past time.',
  },
  {
    category: 'grammar',
    pattern: /\b(a) ([aeiou][a-z-]*)\b/gi,
    replacement: (_, article: string, word: string) => `${article === 'A' ? 'An' : 'an'} ${word}`,
    explanation: () => 'Use “an” before a word that begins with a vowel sound.',
  },
  {
    category: 'grammar',
    pattern: /\b(an) ([bcdfghjklmnpqrstvwxyz][a-z-]*)\b/gi,
    replacement: (_, article: string, word: string) => `${article === 'An' ? 'A' : 'a'} ${word}`,
    explanation: () => 'Use “a” before a word that begins with a consonant sound.',
  },
  {
    category: 'grammar',
    pattern: /\b(liked|ate|bought|picked|saw) (apple|orange|idea|example|answer|option)\b/gi,
    replacement: (_, verb: string, noun: string) => `${verb} an ${noun}`,
    explanation: () => 'The article “an” was added before a singular countable noun that begins with a vowel sound.',
  },
  {
    category: 'punctuation',
    pattern: /\b(dont|cant|wont|isnt|arent|wasnt|werent|im|ive|youre|theyre|thats)\b/gi,
    replacement: (word: string) => {
      const contractions: Record<string, string> = { dont: "don't", cant: "can't", wont: "won't", isnt: "isn't", arent: "aren't", wasnt: "wasn't", werent: "weren't", im: "I'm", ive: "I've", youre: "you're", theyre: "they're", thats: "that's" }
      const fixed = contractions[word.toLowerCase()]
      return /^[A-Z]/.test(word) && !fixed.startsWith('I') ? fixed[0].toUpperCase() + fixed.slice(1) : fixed
    },
    explanation: () => 'An apostrophe was added to form the standard contraction.',
  },
  {
    category: 'punctuation',
    pattern: /^(However|Therefore|Meanwhile|Finally|First|Next)\s+(?!,)/i,
    replacement: '$1, ',
    explanation: () => 'A comma was added after the introductory transition.',
  },
  {
    category: 'spelling',
    pattern: /\b(teh|recieve|seperate|definately|occured|wich|becuase|adress|alot|untill)\b/gi,
    replacement: (word: string) => {
      const spelling: Record<string, string> = { teh: 'the', recieve: 'receive', seperate: 'separate', definately: 'definitely', occured: 'occurred', wich: 'which', becuase: 'because', adress: 'address', alot: 'a lot', untill: 'until' }
      const fixed = spelling[word.toLowerCase()]
      return /^[A-Z]/.test(word) ? fixed[0].toUpperCase() + fixed.slice(1) : fixed
    },
    explanation: (match, replacement) => `“${match}” was corrected to the standard spelling “${replacement}”.`,
  },
  {
    category: 'punctuation',
    pattern: /\s+([,.;:!?])/g,
    replacement: '$1',
    explanation: () => 'Extra space before punctuation was removed.',
  },
  {
    category: 'punctuation',
    pattern: /([,.;:!?])([^\s”’'"\n])/g,
    replacement: '$1 $2',
    explanation: () => 'A space was added after the punctuation mark.',
  },
  {
    category: 'punctuation',
    pattern: /([!?.,])\1+/g,
    replacement: '$1',
    explanation: () => 'Repeated punctuation was reduced to one mark.',
  },
  {
    category: 'style',
    pattern: /\b(very unique|more better|most easiest)\b/gi,
    replacement: (phrase: string) => ({ 'very unique': 'unique', 'more better': 'better', 'most easiest': 'easiest' })[phrase.toLowerCase()] ?? phrase,
    explanation: () => 'The redundant modifier was removed for clearer writing.',
  },
]

function sentenceCase(text: string, issues: GrammarIssue[]) {
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix: string, letter: string) => {
    const replacement = `${prefix}${letter.toUpperCase()}`
    issues.push({
      id: crypto.randomUUID(),
      category: 'capitalization',
      original: match,
      replacement,
      explanation: 'The first word of a sentence begins with a capital letter.',
    })
    return replacement
  })
}

function addTerminalPunctuation(text: string, issues: GrammarIssue[]) {
  const trimmed = text.trim()
  if (!trimmed || /[.!?][”’'"]?$/.test(trimmed)) return trimmed
  const question = /^(who|what|when|where|why|how|is|are|am|was|were|do|does|did|can|could|would|will|should|have|has)\b/i.test(trimmed)
  const mark = question ? '?' : '.'
  issues.push({
    id: crypto.randomUUID(),
    category: 'punctuation',
    original: trimmed.slice(-1),
    replacement: `${trimmed.slice(-1)}${mark}`,
    explanation: question ? 'A question mark was added to complete the question.' : 'A period was added to complete the sentence.',
  })
  return `${trimmed}${mark}`
}

function readabilityScore(text: string) {
  const words = text.match(/[A-Za-z]+(?:'[A-Za-z]+)?/g) ?? []
  const sentences = Math.max(1, (text.match(/[.!?]+/g) ?? []).length)
  const syllables = words.reduce((total, word) => {
    const normalized = word.toLowerCase().replace(/e$/, '')
    return total + Math.max(1, (normalized.match(/[aeiouy]+/g) ?? []).length)
  }, 0)
  const flesch = 206.835 - 1.015 * (words.length / sentences) - 84.6 * (syllables / Math.max(1, words.length))
  return Math.max(0, Math.min(100, Math.round(flesch)))
}

export function checkGrammar(input: string): GrammarResult {
  const original = input.trim()
  const issues: GrammarIssue[] = []
  let corrected = original.replace(/\s{2,}/g, ' ')

  for (const rule of rules) {
    corrected = corrected.replace(rule.pattern, (...args) => {
      const match = args[0] as string
      const replacement = typeof rule.replacement === 'string'
        ? match.replace(rule.pattern, rule.replacement)
        : rule.replacement(match, ...args.slice(1, -2))
      if (replacement === match) return match
      issues.push({ id: crypto.randomUUID(), category: rule.category, original: match, replacement, explanation: rule.explanation(match, replacement) })
      return replacement
    })
  }

  corrected = sentenceCase(corrected, issues)
  corrected = addTerminalPunctuation(corrected, issues)
  const words = corrected.match(/[A-Za-z]+(?:'[A-Za-z]+)?/g)?.length ?? 0
  const sentences = Math.max(corrected ? 1 : 0, (corrected.match(/[.!?]+/g) ?? []).length)
  const penalty = issues.reduce((total, issue) => total + (issue.category === 'style' ? 3 : 6), 0)

  return {
    original,
    corrected,
    issues,
    score: Math.max(0, 100 - penalty),
    readability: readabilityScore(corrected),
    words,
    sentences,
    mode: 'offline',
  }
}
